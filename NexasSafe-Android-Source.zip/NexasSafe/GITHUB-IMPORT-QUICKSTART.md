# Update the existing Nexas Safe GitHub repository

This archive is deliberately packaged with a top-level `NexasSafe/` directory to match the extraction step in the existing `shafiullahali008/Nexas-safe` GitHub Actions workflow.

1. Download this archive and keep the filename `NexasSafe-Android-Source.zip`.
2. Open the existing `Nexas-safe` repository on GitHub.
3. Use **Add file → Upload files** and choose the new ZIP. Upload it at the repository root and replace the old file with the same name.
4. Commit directly to `main`.
5. Open **Actions**. The existing workflow should start on the ZIP upload. It extracts the archive to `NexasSafe/` and builds `NexasSafe/app`.
6. When the run finishes green, open the run and download the artifact named `NexasSafe-APK` (the artifact name configured in the repository's existing workflow). Extract that artifact ZIP to get the debug APK.

If the repository's workflow has been edited since the earlier screenshots, check that its extract step runs `unzip NexasSafe-Android-Source.zip` and its build step runs `cd NexasSafe && gradle assembleDebug`.

The archive includes its own `.github/workflows/android.yml` too. That workflow is for building the extracted `NexasSafe/` project as the repository root in a separate repository. Do not copy the nested workflow over the current repository's root workflow unless you also move the project files to the repository root.
