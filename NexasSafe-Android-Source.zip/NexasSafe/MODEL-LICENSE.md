# Visual model attribution and license

Nexas Safe can download `nudenet_320n_640_fp16.tflite` from the `enaser/blurguard-models` Hugging Face repository after the user taps **Install AI Model**.

- Model source: https://huggingface.co/enaser/blurguard-models
- Model file: `nudenet_320n_640_fp16.tflite`
- Upstream model: NudeNet 320n (YOLOv8n)
- Model license: AGPL-3.0, as stated by the model repository. The model weights are not authored by the Nexas Safe project.
- Model input/output format and class ordering are described in the upstream model card.

Read the complete upstream model license and attribution before redistribution. If you redistribute the downloaded model or a build containing it, comply with the model's AGPL-3.0 terms and any applicable upstream requirements. Nexas Safe downloads the model into the app's private storage at runtime; it does not bundle the model binary in this source ZIP.

The model is intended for content filtering and can produce false positives and false negatives. It must not be used to make judgements about people.
