package com.nexas.safe;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.os.Build;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.Locale;
import java.util.Set;

/** User-enabled service: enforces selected-app focus rules and checks visible page text locally. */
public class ProtectionAccessibilityService extends AccessibilityService {
    private static final long BLOCK_COOLDOWN_MS = 2200L;
    private long lastBlockAt;
    public static final String ACTION_VISUAL_BLOCK = "com.nexas.safe.VISUAL_BLOCK";
    private final BroadcastReceiver visualBlockReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (intent != null) {
                performGlobalAction(GLOBAL_ACTION_HOME);
                showBlockScreen("image");
            }
        }
    };

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        IntentFilter filter = new IntentFilter(ACTION_VISUAL_BLOCK);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(visualBlockReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(visualBlockReceiver, filter);
    }

    @Override public void onDestroy() {
        try { unregisterReceiver(visualBlockReceiver); } catch (Exception ignored) { }
        super.onDestroy();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        String packageName = event.getPackageName().toString();
        ProtectionPrefs.prefs(this).edit().putString(ProtectionPrefs.KEY_CURRENT_PACKAGE, packageName).apply();
        if (packageName.equals(getPackageName()) || packageName.equals("com.android.systemui")) return;

        if (ProtectionPrefs.isFocusActive(this)
                && ProtectionPrefs.blockedPackages(this).contains(packageName.toLowerCase(Locale.ROOT))) {
            performGlobalAction(GLOBAL_ACTION_HOME);
            showBlockScreen("focus");
            return;
        }

        if (!ProtectionPrefs.keywordProtectionEnabled(this)) return;
        int type = event.getEventType();
        if (type != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                && type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;

        Set<String> keywords = ProtectionPrefs.keywords(this);
        if (keywords.isEmpty()) return;
        for (CharSequence text : event.getText()) {
            if (text != null && containsKeyword(text.toString(), keywords)) {
                showBlockScreen("keyword");
                return;
            }
        }
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        try {
            if (containsKeywordInTree(root, 0, keywords)) showBlockScreen("keyword");
        } finally {
            root.recycle();
        }
    }

    private boolean containsKeywordInTree(AccessibilityNodeInfo node, int depth, Set<String> keywords) {
        if (node == null || depth > 20) return false;
        CharSequence text = node.getText();
        if (text != null && containsKeyword(text.toString(), keywords)) return true;
        CharSequence description = node.getContentDescription();
        if (description != null && containsKeyword(description.toString(), keywords)) return true;
        int count = Math.min(node.getChildCount(), 70);
        for (int i = 0; i < count; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                boolean found = containsKeywordInTree(child, depth + 1, keywords);
                child.recycle();
                if (found) return true;
            }
        }
        return false;
    }

    private boolean containsKeyword(String text, Set<String> keywords) {
        String normalized = text.toLowerCase(Locale.ROOT);
        for (String keyword : keywords) {
            if (normalized.contains(keyword)) return true;
        }
        return false;
    }

    private void showBlockScreen(String reason) {
        long now = System.currentTimeMillis();
        if (now - lastBlockAt < BLOCK_COOLDOWN_MS) return;
        lastBlockAt = now;
        Intent intent = new Intent(this, BlockActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        intent.putExtra("reason", reason);
        startActivity(intent);
    }

    @Override public void onInterrupt() { }
}
