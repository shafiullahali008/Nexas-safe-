package com.nexas.safe;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.content.res.ColorStateList;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.CheckBox;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.animation.ObjectAnimator;
import android.animation.AnimatorSet;
import android.animation.ValueAnimator;

public class MainActivity extends Activity {
    private static final int REQUEST_ADMIN = 410;
    private static final int REQUEST_SCREEN_CAPTURE = 411;
    private static final int REQUEST_IMAGE = 412;
    private static final int REQUEST_NOTIFICATIONS = 413;
    private static final int REQUEST_BLOCK_IMAGE = 414;

    private static final int BG = Color.rgb(246, 248, 252);
    private static final int PANEL = Color.rgb(255, 255, 255);
    private static final int PANEL_ALT = Color.rgb(239, 244, 249);
    private static final int OUTLINE = Color.rgb(224, 231, 240);
    private static final int WHITE = Color.rgb(27, 41, 61);
    private static final int MUTED = Color.rgb(108, 124, 146);
    private static final int TEAL = Color.rgb(20, 164, 139);
    private static final int VIOLET = Color.rgb(115, 101, 211);
    private static final int AMBER = Color.rgb(196, 133, 35);
    private static final int RED = Color.rgb(210, 76, 100);
    private int sectionIndex = 0;
    private Boolean liveButtonVisualState = null;

    private final android.os.Handler handler = new android.os.Handler();
    private final ExecutorService scanExecutor = Executors.newSingleThreadExecutor();
    private TextView focusStatus;
    private TextView focusSubtitle;
    private TextView aiStatus;
    private TextView aiProgressText;
    private TextView appSelectionStatus;
    private TextView accessibilityStatus;
    private TextView adminStatus;
    private TextView signalStatus;
    private TextView liveStatus;
    private TextView shieldPill;
    private ProgressBar aiProgress;
    private EditText keywordInput;
    private EditText signalMessageInput;
    private Button startFocusButton;
    private Button liveButton;
    private CheckBox strictModeCheck;
    private EditText blockScreenTextInput;
    private TextView blockImageStatus;
    private TextView streakStatus;
    private TextView pointsStatus;
    private TextView bestStreakStatus;
    private CountdownDial countdownDial;
    private TextView dailyGoalStatus;
    private ProgressBar dailyGoalProgress;
    private EditText intentionInput;
    private long selectedDurationMs = 45L * 60L * 1000L;
    private String selectedDurationLabel = "45 min";

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            refreshStatuses();
            handler.postDelayed(this, 1000L);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        ensureNotificationPermission();
        buildUi();
    }

    @Override protected void onResume() {
        super.onResume();
        refreshStatuses();
        handler.removeCallbacks(ticker);
        handler.post(ticker);
    }

    @Override protected void onPause() {
        super.onPause();
        handler.removeCallbacks(ticker);
    }

    @Override protected void onDestroy() {
        scanExecutor.shutdown();
        super.onDestroy();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(34));
        root.setBackgroundColor(BG);
        scroll.addView(root);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("NEXAS  /  SAFE", 12, TEAL, true);
        brand.setLetterSpacing(0.18f);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView version = text("V3.3  •  CREATOR EDITION", 10, MUTED, true);
        header.addView(version);
        root.addView(header);

        TextView title = text("Make space\nfor what matters.", 32, WHITE, true);
        title.setTypeface(Typeface.create("serif", Typeface.BOLD));
        title.setLineSpacing(dp(1), 1.0f);
        LinearLayout.LayoutParams titleLp = fullWrap();
        titleLp.topMargin = dp(18);
        root.addView(title, titleLp);
        TextView intro = text("A personal protection suite for calmer, more intentional screen time.", 14, MUTED, false);
        LinearLayout.LayoutParams introLp = fullWrap(); introLp.topMargin = dp(8); introLp.bottomMargin = dp(18);
        root.addView(intro, introLp);

        // Personal creator profile: uses the photo supplied by the app owner.
        addCreatorProfile(root);

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(20), dp(20), dp(20), dp(20));
        hero.setBackground(gradient(new int[]{Color.rgb(224, 249, 242), Color.rgb(234, 240, 255), Color.rgb(250, 241, 255)}, 24, Color.rgb(226, 232, 244)));
        LinearLayout heroTop = new LinearLayout(this);
        heroTop.setGravity(Gravity.CENTER_VERTICAL);
        TextView shield = text("◈", 29, TEAL, true);
        heroTop.addView(shield);
        LinearLayout statusBlock = new LinearLayout(this);
        statusBlock.setOrientation(LinearLayout.VERTICAL);
        statusBlock.setPadding(dp(12), 0, 0, 0);
        statusBlock.addView(text("LIVE SHIELD", 10, TEAL, true));
        focusStatus = text("Protection is ready", 18, WHITE, true);
        LinearLayout.LayoutParams fslp = fullWrap(); fslp.topMargin = dp(4);
        statusBlock.addView(focusStatus, fslp);
        heroTop.addView(statusBlock, new LinearLayout.LayoutParams(0, -2, 1f));
        shieldPill = text("●  READY", 10, TEAL, true);
        shieldPill.setPadding(dp(10), dp(7), dp(10), dp(7));
        shieldPill.setBackground(round(Color.rgb(235, 251, 246), 40, Color.rgb(198, 237, 225)));
        heroTop.addView(shieldPill);
        hero.addView(heroTop);
        focusSubtitle = text("A calmer digital routine, with protection and progress kept on your device.", 12, MUTED, false);
        LinearLayout.LayoutParams hslp = fullWrap(); hslp.topMargin = dp(16);
        hero.addView(focusSubtitle, hslp);
        root.addView(hero, fullWrap());
        animateEntrance(hero, 60);
        pulse(shield);

        LinearLayout timerCard = card();
        LinearLayout timerHeading = new LinearLayout(this);
        timerHeading.setGravity(Gravity.CENTER_VERTICAL);
        TextView timerTitle = text("YOUR FOCUS TIMER", 11, WHITE, true);
        timerTitle.setLetterSpacing(0.10f);
        timerHeading.addView(timerTitle, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView timerTag = text("LIVE COUNTDOWN", 9, TEAL, true);
        timerTag.setLetterSpacing(0.08f);
        timerHeading.addView(timerTag);
        timerCard.addView(timerHeading);
        countdownDial = new CountdownDial(this);
        LinearLayout.LayoutParams dialLp = new LinearLayout.LayoutParams(dp(222), dp(222));
        dialLp.gravity = Gravity.CENTER_HORIZONTAL;
        dialLp.topMargin = dp(6);
        timerCard.addView(countdownDial, dialLp);
        TextView timerHint = text("The timer keeps its time when you move between apps or reopen Nexas Safe.", 11, MUTED, false);
        timerHint.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams thLp = fullWrap(); thLp.topMargin = dp(3);
        timerCard.addView(timerHint, thLp);
        LinearLayout.LayoutParams timerCardLp = fullWrap(); timerCardLp.topMargin = dp(13);
        root.addView(timerCard, timerCardLp);
        animateEntrance(timerCard, 90);
        ObjectAnimator dialBreathX = ObjectAnimator.ofFloat(countdownDial, View.SCALE_X, 1f, 1.018f, 1f);
        ObjectAnimator dialBreathY = ObjectAnimator.ofFloat(countdownDial, View.SCALE_Y, 1f, 1.018f, 1f);
        dialBreathX.setDuration(3600L); dialBreathY.setDuration(3600L);
        dialBreathX.setRepeatCount(ValueAnimator.INFINITE); dialBreathY.setRepeatCount(ValueAnimator.INFINITE);
        dialBreathX.setInterpolator(new AccelerateDecelerateInterpolator()); dialBreathY.setInterpolator(new AccelerateDecelerateInterpolator());
        AnimatorSet dialBreath = new AnimatorSet(); dialBreath.playTogether(dialBreathX, dialBreathY); dialBreath.start();

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        addStat(stats, "KEYWORDS", "LOCAL", TEAL);
        addStat(stats, "IMAGE AI", "MODEL", VIOLET);
        addStat(stats, "APP LOCK", "TIMED", AMBER);
        LinearLayout.LayoutParams statsLp = fullWidth(); statsLp.topMargin = dp(12);
        root.addView(stats, statsLp);

        // AI visual protection
        sectionHeader(root, "VISUAL PROTECTION", "ON-DEVICE MODEL");
        LinearLayout aiCard = card();
        aiStatus = text("AI model is not installed", 16, WHITE, true);
        aiCard.addView(aiStatus);
        TextView aiExplain = text("Install the local detector once, then test an image or start a screen-scan session. Automatic blocking uses Accessibility; screen capture requires your consent.", 12, MUTED, false);
        LinearLayout.LayoutParams aelp = fullWrap(); aelp.topMargin = dp(7); aiCard.addView(aiExplain, aelp);
        aiProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        aiProgress.setMax(100); aiProgress.setProgress(0); aiProgress.setVisibility(View.GONE);
        LinearLayout.LayoutParams aplp = fullWidth(); aplp.topMargin = dp(13); aiCard.addView(aiProgress, aplp);
        aiProgressText = text("", 11, MUTED, false);
        LinearLayout.LayoutParams aptp = fullWrap(); aptp.topMargin = dp(5); aiCard.addView(aiProgressText, aptp);
        Button installModel = button("INSTALL AI MODEL", TEAL);
        LinearLayout.LayoutParams imlp = fullWidth(); imlp.topMargin = dp(14); aiCard.addView(installModel, imlp);
        installModel.setOnClickListener(v -> installModel());
        LinearLayout scanRow = new LinearLayout(this); scanRow.setOrientation(LinearLayout.HORIZONTAL);
        Button testImage = button("TEST IMAGE", VIOLET);
        Button liveScan = button("START LIVE SCAN", PANEL_ALT);
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, dp(48), 1f); half.rightMargin = dp(6);
        scanRow.addView(testImage, half);
        LinearLayout.LayoutParams half2 = new LinearLayout.LayoutParams(0, dp(48), 1f); half2.leftMargin = dp(6);
        scanRow.addView(liveScan, half2);
        LinearLayout.LayoutParams srlp = fullWidth(); srlp.topMargin = dp(9); aiCard.addView(scanRow, srlp);
        testImage.setOnClickListener(v -> openImagePicker());
        liveButton = liveScan;
        liveScan.setOnClickListener(v -> toggleLiveScan());
        liveStatus = text("Live screen analysis requires Android screen-capture consent and shows an ongoing notification.", 11, MUTED, false);
        LinearLayout.LayoutParams lslp = fullWrap(); lslp.topMargin = dp(10); aiCard.addView(liveStatus, lslp);
        root.addView(aiCard);
        animateEntrance(aiCard, 130);

        // Focus mode + app picker
        sectionHeader(root, "FOCUS MODE", "APP BLOCKER");
        LinearLayout focusCard = card();
        TextView focusHelp = text("Choose the apps that distract you. They will be sent away while your timed session is active.", 12, MUTED, false);
        focusCard.addView(focusHelp);
        strictModeCheck = new CheckBox(this);
        strictModeCheck.setText("STRICT MODE  •  30-second early-exit pause");
        strictModeCheck.setTextColor(WHITE);
        strictModeCheck.setTextSize(12);
        strictModeCheck.setButtonTintList(android.content.res.ColorStateList.valueOf(TEAL));
        strictModeCheck.setChecked(ProtectionPrefs.isStrictMode(this));
        LinearLayout.LayoutParams strictLp = fullWrap(); strictLp.topMargin = dp(10);
        focusCard.addView(strictModeCheck, strictLp);
        TextView strictNote = text("Opening Nexas Safe never ends your session. Ending early requires a 30-second pause and a second confirmation. Android recovery and uninstall controls always remain available.", 11, MUTED, false);
        LinearLayout.LayoutParams strictNoteLp = fullWrap(); strictNoteLp.topMargin = dp(3); focusCard.addView(strictNote, strictNoteLp);
        Button chooseApps = button("CHOOSE APPS TO BLOCK", PANEL_ALT);
        LinearLayout.LayoutParams cap = fullWidth(); cap.topMargin = dp(13); focusCard.addView(chooseApps, cap);
        chooseApps.setOnClickListener(v -> showAppPicker());
        appSelectionStatus = text("No apps selected yet", 12, MUTED, false);
        LinearLayout.LayoutParams aslp = fullWrap(); aslp.topMargin = dp(8); focusCard.addView(appSelectionStatus, aslp);

        TextView durationLabel = text("SESSION LENGTH", 10, MUTED, true);
        LinearLayout.LayoutParams dlp = fullWrap(); dlp.topMargin = dp(17); focusCard.addView(durationLabel, dlp);
        LinearLayout durations1 = new LinearLayout(this); durations1.setOrientation(LinearLayout.HORIZONTAL);
        addDuration(durations1, "25 MIN", 25, 0);
        addDuration(durations1, "45 MIN", 45, 0);
        addDuration(durations1, "1 HOUR", 60, 0);
        LinearLayout durations2 = new LinearLayout(this); durations2.setOrientation(LinearLayout.HORIZONTAL);
        addDuration(durations2, "2 HOURS", 120, 0);
        Button customDuration = smallButton("CUSTOM", VIOLET);
        LinearLayout.LayoutParams customLp = new LinearLayout.LayoutParams(0, dp(42), 1f); customLp.rightMargin = dp(5);
        durations2.addView(customDuration, customLp);
        customDuration.setOnClickListener(v -> chooseCustomDuration());
        LinearLayout.LayoutParams d1 = fullWidth(); d1.topMargin = dp(9); focusCard.addView(durations1, d1);
        LinearLayout.LayoutParams d2 = fullWidth(); d2.topMargin = dp(7); focusCard.addView(durations2, d2);
        startFocusButton = button("START FOCUS SESSION", TEAL);
        LinearLayout.LayoutParams startLp = fullWidth(); startLp.topMargin = dp(14); focusCard.addView(startFocusButton, startLp);
        startFocusButton.setOnClickListener(v -> startFocus());
        Button endFocus = smallButton("END ACTIVE SESSION", RED);
        LinearLayout.LayoutParams endLp = fullWidth(); endLp.topMargin = dp(8); focusCard.addView(endFocus, endLp);
        endFocus.setOnClickListener(v -> confirmEndFocus());
        root.addView(focusCard);
        animateEntrance(focusCard, 200);

        sectionHeader(root, "DAILY INTENTION", "SET YOUR DIRECTION");
        LinearLayout intentionCard = card();
        TextView intentionHelp = text("Write one small thing you want to finish today. Your note stays on this device.", 12, MUTED, false);
        intentionCard.addView(intentionHelp);
        intentionInput = editText(ProtectionPrefs.prefs(this).getString(ProtectionPrefs.KEY_DAILY_INTENTION, ""), "Today, I will focus on…");
        LinearLayout.LayoutParams intentionInputLp = fullWidth(); intentionInputLp.height = dp(62); intentionInputLp.topMargin = dp(10);
        intentionCard.addView(intentionInput, intentionInputLp);
        Button saveIntention = button("SAVE MY INTENTION", PANEL_ALT);
        LinearLayout.LayoutParams saveIntentionLp = fullWidth(); saveIntentionLp.topMargin = dp(8);
        intentionCard.addView(saveIntention, saveIntentionLp);
        saveIntention.setOnClickListener(v -> {
            String note = intentionInput.getText().toString().trim();
            if (note.length() > 120) note = note.substring(0, 120);
            ProtectionPrefs.prefs(this).edit().putString(ProtectionPrefs.KEY_DAILY_INTENTION, note).apply();
            hideKeyboard(intentionInput); toast("Daily intention saved");
        });
        root.addView(intentionCard);
        animateEntrance(intentionCard, 215);

        sectionHeader(root, "DAILY FOCUS GOAL", "SMALL STEPS ADD UP");
        LinearLayout goalCard = card();
        dailyGoalStatus = text("0 / 120 minutes today", 14, WHITE, true);
        goalCard.addView(dailyGoalStatus);
        dailyGoalProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        dailyGoalProgress.setMax(100); dailyGoalProgress.setProgress(0);
        dailyGoalProgress.setProgressTintList(android.content.res.ColorStateList.valueOf(TEAL));
        dailyGoalProgress.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(231, 237, 244)));
        LinearLayout.LayoutParams goalProgressLp = fullWidth(); goalProgressLp.topMargin = dp(12); goalCard.addView(dailyGoalProgress, goalProgressLp);
        TextView goalHelp = text("Choose a daily target. Completed focus sessions add to your progress.", 11, MUTED, false);
        LinearLayout.LayoutParams goalHelpLp = fullWrap(); goalHelpLp.topMargin = dp(8); goalCard.addView(goalHelp, goalHelpLp);
        LinearLayout goalButtons = new LinearLayout(this); goalButtons.setOrientation(LinearLayout.HORIZONTAL);
        int[] goals = new int[]{60, 120, 180, 240};
        for (int minutes : goals) {
            Button goalButton = smallButton((minutes / 60) + " HR", PANEL_ALT);
            LinearLayout.LayoutParams goalButtonLp = new LinearLayout.LayoutParams(0, dp(42), 1f); goalButtonLp.rightMargin = dp(5);
            goalButtons.addView(goalButton, goalButtonLp);
            goalButton.setOnClickListener(v -> {
                ProtectionPrefs.prefs(this).edit().putInt(ProtectionPrefs.KEY_DAILY_GOAL_MINUTES, minutes).apply();
                refreshStatuses(); toast("Daily goal set to " + (minutes / 60) + " hour(s)");
            });
        }
        LinearLayout.LayoutParams goalButtonsLp = fullWidth(); goalButtonsLp.topMargin = dp(10); goalCard.addView(goalButtons, goalButtonsLp);
        root.addView(goalCard);
        animateEntrance(goalCard, 230);

        // Streaks, rewards and quick focus games
        sectionHeader(root, "STREAKS & REWARDS", "BUILD CONSISTENCY");
        LinearLayout rewardsCard = card();
        LinearLayout rewardStats = new LinearLayout(this);
        rewardStats.setOrientation(LinearLayout.HORIZONTAL);
        streakStatus = text("0 day streak", 15, TEAL, true);
        pointsStatus = text("0 pts", 15, VIOLET, true);
        bestStreakStatus = text("Best 0", 15, AMBER, true);
        rewardStats.addView(streakStatus, new LinearLayout.LayoutParams(0, -2, 1f));
        rewardStats.addView(pointsStatus, new LinearLayout.LayoutParams(0, -2, 1f));
        rewardStats.addView(bestStreakStatus, new LinearLayout.LayoutParams(0, -2, 1f));
        rewardsCard.addView(rewardStats);
        TextView rewardHelp = text("Complete a full timed focus session to earn points and maintain your streak. Ending early does not count as a completed day.", 11, MUTED, false);
        LinearLayout.LayoutParams rhp = fullWrap(); rhp.topMargin = dp(10); rewardsCard.addView(rewardHelp, rhp);
        LinearLayout gameRow = new LinearLayout(this); gameRow.setOrientation(LinearLayout.HORIZONTAL);
        Button breathe = button("BREATH RESET", PANEL_ALT);
        Button memory = button("PATTERN GAME", PANEL_ALT);
        LinearLayout.LayoutParams gameLp1 = new LinearLayout.LayoutParams(0, dp(48), 1f); gameLp1.rightMargin = dp(5);
        LinearLayout.LayoutParams gameLp2 = new LinearLayout.LayoutParams(0, dp(48), 1f); gameLp2.leftMargin = dp(5);
        gameRow.addView(breathe, gameLp1); gameRow.addView(memory, gameLp2);
        LinearLayout.LayoutParams grlp = fullWidth(); grlp.topMargin = dp(13); rewardsCard.addView(gameRow, grlp);
        breathe.setOnClickListener(v -> startBreathingReset());
        memory.setOnClickListener(v -> startPatternGame());
        Button quickSprint = button("START 25-MIN QUICK SPRINT", TEAL);
        LinearLayout.LayoutParams qslp = fullWidth(); qslp.topMargin = dp(9); rewardsCard.addView(quickSprint, qslp);
        quickSprint.setOnClickListener(v -> {
            selectedDurationMs = 25L * 60L * 1000L;
            selectedDurationLabel = "25 min quick sprint";
            startFocus();
        });
        root.addView(rewardsCard);
        animateEntrance(rewardsCard, 235);

        // Personalised blocking screen
        sectionHeader(root, "YOUR BLOCK SCREEN", "MAKE IT YOURS");
        LinearLayout blockCustomCard = card();
        TextView customHelp = text("Choose the message that appears when Nexas Safe catches a selected distraction. You can also add a personal image. The close control only dismisses the block screen; it does not switch Focus Mode off.", 11, MUTED, false);
        blockCustomCard.addView(customHelp);
        blockScreenTextInput = editText(ProtectionPrefs.prefs(this).getString(ProtectionPrefs.KEY_BLOCK_SCREEN_TEXT, "This content has been blocked to protect your focus."), "Your personal reminder");
        LinearLayout.LayoutParams bti = fullWidth(); bti.height = dp(84); bti.topMargin = dp(11); blockCustomCard.addView(blockScreenTextInput, bti);
        Button saveBlockText = button("SAVE BLOCK SCREEN MESSAGE", PANEL_ALT);
        LinearLayout.LayoutParams sbtlp = fullWidth(); sbtlp.topMargin = dp(8); blockCustomCard.addView(saveBlockText, sbtlp);
        saveBlockText.setOnClickListener(v -> {
            String value = blockScreenTextInput.getText().toString().trim();
            if (value.length() > 180) value = value.substring(0, 180);
            ProtectionPrefs.prefs(this).edit().putString(ProtectionPrefs.KEY_BLOCK_SCREEN_TEXT, value).apply();
            hideKeyboard(blockScreenTextInput); toast("Block screen message saved");
        });
        blockImageStatus = text("No custom block-screen image selected", 11, MUTED, false);
        LinearLayout.LayoutParams bislp = fullWrap(); bislp.topMargin = dp(10); blockCustomCard.addView(blockImageStatus, bislp);
        Button pickBlockImage = button("UPLOAD BLOCK SCREEN IMAGE", VIOLET);
        LinearLayout.LayoutParams pbilp = fullWidth(); pbilp.topMargin = dp(8); blockCustomCard.addView(pickBlockImage, pbilp);
        pickBlockImage.setOnClickListener(v -> pickBlockScreenImage());
        Button clearBlockImage = smallButton("REMOVE CUSTOM IMAGE", PANEL_ALT);
        LinearLayout.LayoutParams cbilp = fullWidth(); cbilp.topMargin = dp(7); blockCustomCard.addView(clearBlockImage, cbilp);
        clearBlockImage.setOnClickListener(v -> {
            String old = ProtectionPrefs.prefs(this).getString(ProtectionPrefs.KEY_BLOCK_SCREEN_IMAGE, "");
            if (old != null && !old.isEmpty()) try { getContentResolver().releasePersistableUriPermission(Uri.parse(old), Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
            ProtectionPrefs.prefs(this).edit().remove(ProtectionPrefs.KEY_BLOCK_SCREEN_IMAGE).apply();
            refreshStatuses(); toast("Custom image removed");
        });
        root.addView(blockCustomCard);
        animateEntrance(blockCustomCard, 270);

        // 24-item overview of included tools
        sectionHeader(root, "THE FOCUS COLLECTION", "30 WAYS TO RESET");
        LinearLayout suiteCard = card();
        String[] suite = new String[]{
                "01  Timed focus sessions", "02  Strict Mode delay", "03  App distraction blocker", "04  Nexas Safe app allowlist",
                "05  Live session countdown", "06  Custom timer lengths", "07  Quick 25-minute sprint", "08  Local keyword filter",
                "09  On-device image checks", "10  User-approved live scan", "11  Custom block message", "12  Personal block-screen image",
                "13  Daily focus streaks", "14  Best-streak tracking", "15  Focus reward points", "16  Pattern memory mini-game",
                "17  Breathing reset exercise", "18  Daily reminder signal", "19  Custom reminder text", "20  Session completion reward",
                "21  Private on-device checks", "22  Optional app selection", "23  Persistent timer after reopen", "24  Emergency session recovery",
                "25  Personal daily intention", "26  Daily focus-minute target", "27  Live circular countdown dial", "28  Gentle progress animations",
                "29  Custom focus-session length", "30  Light-theme accessibility contrast"
        };
        for (String item : suite) {
            TextView line = text("✦  " + item, 11, WHITE, false);
            line.setPadding(dp(2), dp(6), dp(2), dp(6));
            suiteCard.addView(line);
        }
        root.addView(suiteCard);
        animateEntrance(suiteCard, 300);

        // Keyword filter
        sectionHeader(root, "TEXT FILTER", "BEST-EFFORT KEYWORDS");
        LinearLayout keywordCard = card();
        TextView keywordHelp = text("Checks text exposed by supported apps and pages. This does not identify images or video frames; use the AI scan for visual checks.", 12, MUTED, false);
        keywordCard.addView(keywordHelp);
        keywordInput = editText(ProtectionPrefs.prefs(this).getString(ProtectionPrefs.KEY_CUSTOM_KEYWORDS, ProtectionPrefs.defaultKeywords()), "Comma-separated words");
        LinearLayout.LayoutParams kilp = fullWidth(); kilp.height = dp(82); kilp.topMargin = dp(12); keywordCard.addView(keywordInput, kilp);
        Button saveKeywords = button("SAVE KEYWORD FILTER", PANEL_ALT);
        LinearLayout.LayoutParams sklp = fullWidth(); sklp.topMargin = dp(9); keywordCard.addView(saveKeywords, sklp);
        saveKeywords.setOnClickListener(v -> {
            ProtectionPrefs.prefs(this).edit().putString(ProtectionPrefs.KEY_CUSTOM_KEYWORDS, keywordInput.getText().toString()).apply();
            hideKeyboard(keywordInput);
            toast("Keyword filter saved");
        });
        root.addView(keywordCard);
        animateEntrance(keywordCard, 270);

        // Custom time signal
        sectionHeader(root, "CUSTOM TIME SIGNAL", "DAILY REMINDER");
        LinearLayout reminderCard = card();
        signalStatus = text("No daily signal scheduled", 15, WHITE, true);
        reminderCard.addView(signalStatus);
        TextView reminderHelp = text("Choose a time for a reminder with sound and vibration. Android may delay it when exact-alarm access is unavailable.", 12, MUTED, false);
        LinearLayout.LayoutParams rhlp = fullWrap(); rhlp.topMargin = dp(7); reminderCard.addView(reminderHelp, rhlp);
        signalMessageInput = editText(ProtectionPrefs.prefs(this).getString(ProtectionPrefs.KEY_REMINDER_MESSAGE, "Pause. Reset. Return to what matters."), "Reminder message");
        LinearLayout.LayoutParams smlp = fullWidth(); smlp.height = dp(62); smlp.topMargin = dp(12); reminderCard.addView(signalMessageInput, smlp);
        Button setSignal = button("SET CUSTOM TIME SIGNAL", AMBER);
        LinearLayout.LayoutParams sslp = fullWidth(); sslp.topMargin = dp(10); reminderCard.addView(setSignal, sslp);
        setSignal.setOnClickListener(v -> chooseReminderTime());
        Button disableSignal = smallButton("TURN OFF DAILY SIGNAL", PANEL_ALT);
        LinearLayout.LayoutParams dslp = fullWidth(); dslp.topMargin = dp(7); reminderCard.addView(disableSignal, dslp);
        disableSignal.setOnClickListener(v -> {
            ReminderScheduler.cancel(this);
            refreshStatuses();
            toast("Daily signal turned off");
        });
        root.addView(reminderCard);
        animateEntrance(reminderCard, 340);

        // Permissions and setup
        sectionHeader(root, "PERMISSIONS", "YOU STAY IN CONTROL");
        LinearLayout permCard = card();
        accessibilityStatus = text("Accessibility: checking…", 13, WHITE, true);
        permCard.addView(accessibilityStatus);
        Button accessibilityButton = button("OPEN ACCESSIBILITY SETTINGS", PANEL_ALT);
        LinearLayout.LayoutParams aclp = fullWidth(); aclp.topMargin = dp(10); permCard.addView(accessibilityButton, aclp);
        accessibilityButton.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        adminStatus = text("Device Admin: optional", 13, MUTED, true);
        LinearLayout.LayoutParams adlp = fullWrap(); adlp.topMargin = dp(17); permCard.addView(adminStatus, adlp);
        Button adminButton = button("ENABLE OPTIONAL DEVICE ADMIN", PANEL_ALT);
        LinearLayout.LayoutParams adbp = fullWidth(); adbp.topMargin = dp(9); permCard.addView(adminButton, adbp);
        adminButton.setOnClickListener(v -> requestDeviceAdmin());
        TextView adminNote = text("Device Admin can add uninstall friction but cannot make the app undeletable. You can always revoke permissions in Android Settings.", 11, MUTED, false);
        LinearLayout.LayoutParams anlp = fullWrap(); anlp.topMargin = dp(9); permCard.addView(adminNote, anlp);
        root.addView(permCard);
        animateEntrance(permCard, 410);

        TextView footer = text("NEXAS SAFE  •  STAY PURE  •  BUILT FOR BETTER HABITS", 9, Color.rgb(145, 157, 174), true);
        footer.setGravity(Gravity.CENTER);
        footer.setLetterSpacing(0.08f);
        LinearLayout.LayoutParams footLp = fullWrap(); footLp.topMargin = dp(24); root.addView(footer, footLp);

        setContentView(scroll);
        refreshStatuses();
    }


    private void addCreatorProfile(LinearLayout root) {
        sectionHeader(root, "ABOUT THE CREATOR", "THE PERSON BEHIND NEXAS");
        LinearLayout profile = card();

        LinearLayout hero = new LinearLayout(this);
        hero.setGravity(Gravity.CENTER_VERTICAL);
        hero.setPadding(dp(13), dp(13), dp(13), dp(13));
        hero.setBackground(gradient(new int[]{Color.rgb(231, 250, 245), Color.rgb(239, 242, 255), Color.rgb(250, 243, 255)}, 20, OUTLINE));

        ImageView portrait = new ImageView(this);
        portrait.setImageResource(R.drawable.profile_shafi);
        portrait.setScaleType(ImageView.ScaleType.CENTER_CROP);
        portrait.setBackground(round(PANEL, 18, Color.rgb(206, 222, 229)));
        portrait.setClipToOutline(true);
        portrait.setContentDescription("Profile photograph of Shafiullah Ali");
        portrait.setElevation(dp(3));
        LinearLayout.LayoutParams portraitLp = new LinearLayout.LayoutParams(dp(104), dp(130));
        portraitLp.rightMargin = dp(13);
        hero.addView(portrait, portraitLp);

        LinearLayout identity = new LinearLayout(this);
        identity.setOrientation(LinearLayout.VERTICAL);
        identity.addView(text("PERSONAL PROFILE", 9, TEAL, true));
        TextView displayName = text("Shafiullah Ali", 21, WHITE, true);
        displayName.setTypeface(Typeface.create("serif", Typeface.BOLD));
        LinearLayout.LayoutParams nlp = fullWrap(); nlp.topMargin = dp(5);
        identity.addView(displayName, nlp);
        TextView role = text("Student  •  Technology enthusiast  •  Builder", 11, MUTED, true);
        LinearLayout.LayoutParams rlp = fullWrap(); rlp.topMargin = dp(6);
        identity.addView(role, rlp);
        TextView tagline = text("Curious by nature. Focused on building useful things.", 11, MUTED, false);
        tagline.setLineSpacing(dp(2), 1.04f);
        LinearLayout.LayoutParams tlp = fullWrap(); tlp.topMargin = dp(8);
        identity.addView(tagline, tlp);
        hero.addView(identity, new LinearLayout.LayoutParams(0, -2, 1f));
        profile.addView(hero);

        TextView introHeading = text("A LITTLE INTRODUCTION", 10, TEAL, true);
        introHeading.setLetterSpacing(0.10f);
        LinearLayout.LayoutParams ihp = fullWrap(); ihp.topMargin = dp(18);
        profile.addView(introHeading, ihp);
        TextView introBody = text(
                "I'm a student who enjoys exploring technology, learning how digital products work, and turning ideas into practical projects. My interests include software development, artificial intelligence, mobile apps, cybersecurity, automation, design and entrepreneurship. I like learning by building, testing ideas, improving the details and understanding how things work behind the scenes.",
                13, MUTED, false);
        introBody.setLineSpacing(dp(4), 1.06f);
        LinearLayout.LayoutParams ibp = fullWrap(); ibp.topMargin = dp(7);
        profile.addView(introBody, ibp);

        addProfileBlock(profile, "EDUCATION & LEARNING",
                "Currently studying the ICS track, with Computer Science, Mathematics and Statistics. I use my studies as a foundation for stronger problem-solving, logical thinking and technical skills.");
        addProfileBlock(profile, "TECHNOLOGY INTERESTS",
                "Android app development • Python programming • AI and machine learning • Cybersecurity and digital safety • Web technology • Automation • User-interface and product design.");
        addProfileBlock(profile, "PROJECTS & CREATIVE WORK",
                "Nexas Safe — a personal focus and digital-wellbeing app concept.\nASL Group — developing business and technology ideas under the ASL name.\nInstaFlora — creative work around floral branding, event presentation and digital promotion.");
        addProfileBlock(profile, "SKILLS I'M DEVELOPING",
                "Programming fundamentals, technical problem-solving, product planning, interface design, communication, leadership and organised project work. I treat these as skills to keep improving, not as finished achievements.");
        addProfileBlock(profile, "MY APPROACH",
                "I value consistency, curiosity, discipline and practical learning. I prefer building a working version, learning from what does not work, and refining it step by step rather than relying only on big claims.");
        addProfileBlock(profile, "FUTURE DIRECTION",
                "My goal is to keep learning, create useful technology products, develop meaningful ventures and build a strong foundation for long-term work. The focus is steady progress, useful skills and projects that solve real problems.");

        TextView interestsTitle = text("WHAT I'M INTO", 10, VIOLET, true);
        interestsTitle.setLetterSpacing(0.10f);
        LinearLayout.LayoutParams itp = fullWrap(); itp.topMargin = dp(17);
        profile.addView(interestsTitle, itp);
        LinearLayout tags = new LinearLayout(this);
        tags.setOrientation(LinearLayout.HORIZONTAL);
        tags.setGravity(Gravity.CENTER_VERTICAL);
        String[] tagsText = {"TECH & AI", "BUILDING", "DESIGN", "LEARNING"};
        int[] tagColors = {TEAL, VIOLET, AMBER, TEAL};
        for (int i = 0; i < tagsText.length; i++) {
            TextView chip = text(tagsText[i], 8, tagColors[i], true);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(8), dp(8), dp(8), dp(8));
            chip.setBackground(round(i == 1 ? Color.rgb(244, 241, 255) : (i == 2 ? Color.rgb(255, 247, 232) : Color.rgb(235, 250, 246)), 30, OUTLINE));
            LinearLayout.LayoutParams chipLp = new LinearLayout.LayoutParams(0, dp(34), 1f);
            chipLp.rightMargin = dp(5);
            tags.addView(chip, chipLp);
        }
        LinearLayout.LayoutParams tagsLp = fullWidth(); tagsLp.topMargin = dp(9);
        profile.addView(tags, tagsLp);

        TextView contactTitle = text("LET'S CONNECT", 10, TEAL, true);
        contactTitle.setLetterSpacing(0.10f);
        LinearLayout.LayoutParams ctp = fullWrap(); ctp.topMargin = dp(19);
        profile.addView(contactTitle, ctp);
        TextView handle = text("Instagram  @shafi.viii_", 14, WHITE, true);
        LinearLayout.LayoutParams hlp = fullWrap(); hlp.topMargin = dp(6);
        profile.addView(handle, hlp);
        TextView contactNote = text("For updates, creative work and project-related contact.", 11, MUTED, false);
        LinearLayout.LayoutParams cnlp = fullWrap(); cnlp.topMargin = dp(4);
        profile.addView(contactNote, cnlp);
        LinearLayout contactButtons = new LinearLayout(this);
        contactButtons.setOrientation(LinearLayout.HORIZONTAL);
        Button openInstagram = button("OPEN INSTAGRAM", TEAL);
        Button copyHandle = button("COPY HANDLE", PANEL_ALT);
        LinearLayout.LayoutParams openLp = new LinearLayout.LayoutParams(0, dp(46), 1f); openLp.rightMargin = dp(5);
        LinearLayout.LayoutParams copyLp = new LinearLayout.LayoutParams(0, dp(46), 1f); copyLp.leftMargin = dp(5);
        contactButtons.addView(openInstagram, openLp);
        contactButtons.addView(copyHandle, copyLp);
        LinearLayout.LayoutParams contactLp = fullWidth(); contactLp.topMargin = dp(11);
        profile.addView(contactButtons, contactLp);
        openInstagram.setOnClickListener(v -> openCreatorInstagram());
        copyHandle.setOnClickListener(v -> {
            android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (clipboard != null) {
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Instagram", "@shafi.viii_"));
                toast("Instagram handle copied");
            }
        });

        Button shareProfile = smallButton("SHARE CREATOR PROFILE", PANEL_ALT);
        LinearLayout.LayoutParams shareLp = fullWidth(); shareLp.topMargin = dp(7);
        profile.addView(shareProfile, shareLp);
        shareProfile.setOnClickListener(v -> shareCreatorProfile());

        TextView privacy = text("Profile details are shown locally in this app. The Instagram button opens the public profile link; Nexas Safe does not upload this photo.", 10, MUTED, false);
        LinearLayout.LayoutParams plp = fullWrap(); plp.topMargin = dp(13);
        profile.addView(privacy, plp);
        root.addView(profile);
        animateEntrance(profile, 120);
    }

    private void addProfileBlock(LinearLayout parent, String heading, String body) {
        TextView title = text(heading, 10, VIOLET, true);
        title.setLetterSpacing(0.09f);
        LinearLayout.LayoutParams titleLp = fullWrap(); titleLp.topMargin = dp(15);
        parent.addView(title, titleLp);
        TextView detail = text(body, 12, MUTED, false);
        detail.setLineSpacing(dp(3), 1.04f);
        LinearLayout.LayoutParams detailLp = fullWrap(); detailLp.topMargin = dp(5);
        parent.addView(detail, detailLp);
    }

    private void openCreatorInstagram() {
        Uri instagram = Uri.parse("https://www.instagram.com/shafi.viii_/");
        Intent intent = new Intent(Intent.ACTION_VIEW, instagram);
        try {
            startActivity(intent);
        } catch (Exception ex) {
            toast("Could not open Instagram on this device");
        }
    }

    private void shareCreatorProfile() {
        String message = "Shafiullah Ali\nStudent • Technology enthusiast • Builder\nInterested in software development, AI, Android apps, cybersecurity, automation and entrepreneurship.\nInstagram: https://www.instagram.com/shafi.viii_/";
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_SUBJECT, "About Shafiullah Ali");
        share.putExtra(Intent.EXTRA_TEXT, message);
        startActivity(Intent.createChooser(share, "Share creator profile"));
    }

    private void sectionHeader(LinearLayout root, String title, String caption) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        final String[] glyphs = {"✦", "◈", "⌁", "✧", "◎", "⌘", "◇", "✺", "◉", "✳"};
        final int[][] tints = {
                {Color.rgb(225, 248, 241), Color.rgb(236, 244, 255)},
                {Color.rgb(239, 236, 255), Color.rgb(248, 241, 255)},
                {Color.rgb(255, 244, 225), Color.rgb(255, 249, 237)},
                {Color.rgb(229, 243, 255), Color.rgb(242, 248, 255)}
        };
        int index = sectionIndex++;
        TextView emblem = text(glyphs[index % glyphs.length], 16, index % 3 == 1 ? VIOLET : TEAL, true);
        emblem.setGravity(Gravity.CENTER);
        emblem.setBackground(gradient(tints[index % tints.length], 11, OUTLINE));
        LinearLayout.LayoutParams emblemLp = new LinearLayout.LayoutParams(dp(32), dp(32));
        emblemLp.rightMargin = dp(10);
        row.addView(emblem, emblemLp);
        emblem.setScaleX(0.78f); emblem.setScaleY(0.78f); emblem.setRotation(-14f);
        emblem.animate().scaleX(1f).scaleY(1f).rotation(0f).setStartDelay(Math.min(180, index * 12L))
                .setDuration(420).setInterpolator(new android.view.animation.OvershootInterpolator(1.25f)).start();

        TextView left = text(title, 12, WHITE, true);
        left.setLetterSpacing(0.09f);
        left.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        row.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView right = text(caption, 9, TEAL, true);
        right.setLetterSpacing(0.10f);
        row.addView(right);
        LinearLayout.LayoutParams lp = fullWrap(); lp.topMargin = dp(23); lp.bottomMargin = dp(10);
        root.addView(row, lp);
    }

    private void addStat(LinearLayout row, String label, String value, int accent) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setPadding(dp(12), dp(13), dp(9), dp(13));
        tile.setBackground(round(PANEL, 15, OUTLINE));
        tile.addView(text(label, 9, MUTED, true));
        TextView v = text(value, 14, accent, true);
        LinearLayout.LayoutParams lp = fullWrap(); lp.topMargin = dp(6); tile.addView(v, lp);
        LinearLayout.LayoutParams tileLp = new LinearLayout.LayoutParams(0, dp(74), 1f);
        tileLp.rightMargin = dp(5); tileLp.leftMargin = dp(5); row.addView(tile, tileLp);
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(17), dp(17), dp(17), dp(17));
        box.setBackground(round(PANEL, 20, OUTLINE));
        box.setElevation(dp(3));
        box.setTranslationZ(dp(0));
        if (Build.VERSION.SDK_INT >= 21) box.setClipToOutline(false);
        return box;
    }

    private void addDuration(LinearLayout row, String label, int minutes, int ignored) {
        Button b = smallButton(label, PANEL_ALT);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1f);
        lp.rightMargin = dp(5);
        row.addView(b, lp);
        b.setOnClickListener(v -> {
            selectedDurationMs = minutes * 60_000L;
            selectedDurationLabel = label.toLowerCase(Locale.ROOT);
            toast(label + " selected");
        });
    }

    private void chooseCustomDuration() {
        new TimePickerDialog(this, (view, hour, minute) -> {
            long mins = hour * 60L + minute;
            if (mins < 1) mins = 1;
            selectedDurationMs = mins * 60_000L;
            selectedDurationLabel = String.format(Locale.ROOT, "%dh %02dm", hour, minute);
            toast("Custom duration: " + selectedDurationLabel);
        }, 0, 45, true).show();
    }

    private void startFocus() {
        if (ProtectionPrefs.isFocusActive(this)) {
            toast("Your focus session is already running. The countdown cannot be reset mid-session.");
            return;
        }
        Set<String> selected = ProtectionPrefs.blockedPackages(this);
        long until = System.currentTimeMillis() + selectedDurationMs;
        ProtectionPrefs.prefs(this).edit()
                .putBoolean(ProtectionPrefs.KEY_STRICT_MODE, strictModeCheck != null && strictModeCheck.isChecked())
                .putLong(ProtectionPrefs.KEY_FOCUS_DURATION, selectedDurationMs)
                .putLong(ProtectionPrefs.KEY_FOCUS_UNTIL, until).apply();
        hideKeyboard(keywordInput);
        refreshStatuses();
        if (!isAccessibilityEnabled()) {
            new AlertDialog.Builder(this)
                    .setTitle("One setup step remains")
                    .setMessage("The timer is running, but app blocking needs Nexas Safe Protection enabled in Android Accessibility settings.")
                    .setNegativeButton("Later", null)
                    .setPositiveButton("Open settings", (d, w) -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)))
                    .show();
        } else if (selected.isEmpty()) toast("Focus timer started. Choose apps to enable app blocking.");
        else toast("Focus started • " + selectedDurationLabel + " • " + selected.size() + " apps protected");
    }

    private void confirmEndFocus() {
        if (!ProtectionPrefs.isFocusActive(this)) {
            toast("No active focus session");
            return;
        }
        if (!ProtectionPrefs.isStrictMode(this)) {
            confirmEndFocusNow();
            return;
        }
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Strict Mode is active")
                .setMessage("To end early, pause for 30 seconds and make a deliberate choice. Your timer keeps running unless you confirm.")
                .setNegativeButton("Keep focusing", null)
                .setPositiveButton("Wait 30 seconds", null)
                .create();
        dialog.setOnShowListener(ignored -> {
            Button positive = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            positive.setEnabled(false);
            final long started = android.os.SystemClock.elapsedRealtime();
            final Runnable[] tick = new Runnable[1];
            tick[0] = () -> {
                if (!dialog.isShowing()) return;
                long left = 30_000L - (android.os.SystemClock.elapsedRealtime() - started);
                if (left <= 0) {
                    positive.setText("End session");
                    positive.setEnabled(true);
                } else {
                    positive.setText("Wait " + ((left + 999L) / 1000L) + "s");
                    handler.postDelayed(tick[0], 250L);
                }
            };
            positive.setOnClickListener(v -> {
                if (android.os.SystemClock.elapsedRealtime() - started >= 15_000L) {
                    dialog.dismiss();
                    confirmEndFocusNow();
                }
            });
            tick[0].run();
        });
        dialog.show();
    }

    private void confirmEndFocusNow() {
        new AlertDialog.Builder(this)
                .setTitle("End focus session?")
                .setMessage("This will restore access to the apps you selected. Your completed-session streak is only awarded when the timer reaches zero.")
                .setNegativeButton("Keep focusing", null)
                .setPositiveButton("End session", (dialog, which) -> {
                    ProtectionPrefs.prefs(this).edit().putLong(ProtectionPrefs.KEY_FOCUS_UNTIL, 0L).apply();
                    refreshStatuses();
                    toast("Focus session ended");
                }).show();
    }

    private void showAppPicker() {
        if (ProtectionPrefs.isFocusActive(this)) {
            toast("App restrictions are fixed until this session ends.");
            return;
        }
        List<ResolveInfo> apps = getLaunchableApps();
        if (apps.isEmpty()) {
            toast("No launchable apps were found");
            return;
        }
        Set<String> current = ProtectionPrefs.blockedPackages(this);
        String[] labels = new String[apps.size()];
        boolean[] checked = new boolean[apps.size()];
        Set<String> chosen = new HashSet<>(current);
        for (int i = 0; i < apps.size(); i++) {
            ResolveInfo info = apps.get(i);
            labels[i] = String.valueOf(info.loadLabel(getPackageManager()));
            checked[i] = current.contains(info.activityInfo.packageName.toLowerCase(Locale.ROOT));
        }
        new AlertDialog.Builder(this)
                .setTitle("Choose apps to block")
                .setMultiChoiceItems(labels, checked, (dialog, which, isChecked) -> {
                    String packageName = apps.get(which).activityInfo.packageName.toLowerCase(Locale.ROOT);
                    if (isChecked) chosen.add(packageName); else chosen.remove(packageName);
                })
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save selection", (dialog, which) -> {
                    ProtectionPrefs.saveBlockedPackages(this, chosen);
                    refreshStatuses();
                    toast(chosen.size() + " apps selected");
                }).show();
    }

    private List<ResolveInfo> getLaunchableApps() {
        Intent intent = new Intent(Intent.ACTION_MAIN, null);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> found = getPackageManager().queryIntentActivities(intent, 0);
        java.util.LinkedHashMap<String, ResolveInfo> byPackage = new java.util.LinkedHashMap<>();
        for (ResolveInfo info : found) {
            if (info.activityInfo == null) continue;
            String pkg = info.activityInfo.packageName;
            if (pkg.equals(getPackageName()) || pkg.equals("com.android.settings")) continue;
            byPackage.putIfAbsent(pkg, info);
        }
        List<ResolveInfo> result = new ArrayList<>(byPackage.values());
        result.sort((a, b) -> String.valueOf(a.loadLabel(getPackageManager())).compareToIgnoreCase(String.valueOf(b.loadLabel(getPackageManager()))));
        return result;
    }

    private void installModel() {
        if (ModelManager.isReady(this)) {
            toast("AI model is already installed");
            refreshStatuses();
            return;
        }
        aiProgress.setVisibility(View.VISIBLE);
        aiProgress.setProgress(0);
        aiProgressText.setText("Downloading the on-device model over HTTPS…");
        aiStatus.setText("Installing AI model…");
        ModelManager.download(this, new ModelManager.Callback() {
            @Override public void onProgress(int percent) {
                runOnUiThread(() -> {
                    aiProgress.setProgress(percent);
                    aiProgressText.setText("Downloading model: " + percent + "%");
                });
            }
            @Override public void onComplete(boolean success, String message) {
                runOnUiThread(() -> {
                    aiProgress.setVisibility(View.GONE);
                    aiProgressText.setText(message);
                    refreshStatuses();
                    toast(message);
                });
            }
        });
    }

    private void openImagePicker() {
        if (!ModelManager.isReady(this)) {
            toast("Install the AI model first");
            return;
        }
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType("image/*");
        startActivityForResult(pick, REQUEST_IMAGE);
    }

    private void scanPickedImage(Uri uri) {
        aiStatus.setText("Checking image on this device…");
        scanExecutor.execute(() -> {
            Bitmap bitmap = null;
            try {
                BitmapFactory.Options bounds = new BitmapFactory.Options();
                bounds.inJustDecodeBounds = true;
                try (InputStream boundsInput = getContentResolver().openInputStream(uri)) {
                    BitmapFactory.decodeStream(boundsInput, null, bounds);
                }
                int longest = Math.max(bounds.outWidth, bounds.outHeight);
                int sample = 1;
                while (longest / sample > 1600) sample *= 2;
                BitmapFactory.Options decodeOptions = new BitmapFactory.Options();
                decodeOptions.inSampleSize = sample;
                try (InputStream input = getContentResolver().openInputStream(uri)) {
                    bitmap = BitmapFactory.decodeStream(input, null, decodeOptions);
                }
                if (bitmap == null) throw new IllegalStateException("Could not read selected image");
                ImageSafetyClassifier.Result result;
                try (ImageSafetyClassifier classifier = new ImageSafetyClassifier(ModelManager.modelFile(this))) {
                    result = classifier.classify(bitmap);
                }
                final ImageSafetyClassifier.Result finalResult = result;
                runOnUiThread(() -> {
                    if (finalResult.flagged) {
                        aiStatus.setText("Potentially unsafe visual content detected");
                        new AlertDialog.Builder(this).setTitle("Nexas Safe scan")
                                .setMessage("This image crossed the local safety threshold. It was checked on-device and has not been uploaded or saved by Nexas Safe.")
                                .setPositiveButton("Done", null).show();
                    } else {
                        aiStatus.setText("No high-confidence match found");
                        toast("No high-confidence match. This is not a guarantee that the image is safe.");
                    }
                });
            } catch (Exception ex) {
                runOnUiThread(() -> {
                    aiStatus.setText("Image scan unavailable");
                    toast(ex.getMessage() == null ? "Image scan failed" : ex.getMessage());
                });
            } finally {
                if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
            }
        });
    }

    private void toggleLiveScan() {
        boolean active = ProtectionPrefs.prefs(this).getBoolean(ProtectionPrefs.KEY_LIVE_SCAN, false);
        if (active) {
            stopService(new Intent(this, ScreenCaptureService.class).setAction(ScreenCaptureService.ACTION_STOP));
            return;
        }
        if (!ModelManager.isReady(this)) {
            toast("Install the AI model first");
            return;
        }
        if (!ProtectionPrefs.isAccessibilityEnabled(this)) {
            new AlertDialog.Builder(this)
                    .setTitle("Enable automatic blocking")
                    .setMessage("Turn on Nexas Safe Protection in Accessibility settings first. The live scanner can then trigger the blocking screen when it detects a match.")
                    .setNegativeButton("Not now", null)
                    .setPositiveButton("Open settings", (d, w) -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)))
                    .show();
            return;
        }
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_SCREEN_CAPTURE);
    }

    private void chooseReminderTime() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
        }
        int hour = ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_REMINDER_HOUR, 20);
        int minute = ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_REMINDER_MINUTE, 0);
        new TimePickerDialog(this, (view, h, m) -> {
            ProtectionPrefs.prefs(this).edit().putString(ProtectionPrefs.KEY_REMINDER_MESSAGE,
                    signalMessageInput.getText().toString().trim().isEmpty()
                            ? "Pause. Reset. Return to what matters." : signalMessageInput.getText().toString().trim()).apply();
            ReminderScheduler.schedule(this, h, m);
            refreshStatuses();
            toast(String.format(Locale.ROOT, "Daily signal set for %02d:%02d", h, m));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                android.app.AlarmManager alarm = (android.app.AlarmManager) getSystemService(ALARM_SERVICE);
                if (!alarm.canScheduleExactAlarms()) {
                    new AlertDialog.Builder(this).setTitle("Allow precise reminders?")
                            .setMessage("You can grant Nexas Safe Alarms & reminders access for closer timing. Without it, Android may delay the notification.")
                            .setNegativeButton("Use flexible timing", null)
                            .setPositiveButton("Open settings", (d, w) -> {
                                try { startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)); } catch (Exception ignored) { }
                            }).show();
                }
            }
        }, hour, minute, true).show();
    }

    private void requestDeviceAdmin() {
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
        ComponentName admin = new ComponentName(this, NexasDeviceAdminReceiver.class);
        if (dpm.isAdminActive(admin)) {
            toast("Device Admin is already enabled");
            return;
        }
        Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin);
        intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Optional uninstall friction. This does not prevent the device owner from disabling the admin or uninstalling the app.");
        startActivityForResult(intent, REQUEST_ADMIN);
    }

    private void ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
        }
    }

    private boolean isAccessibilityEnabled() {
        return ProtectionPrefs.isAccessibilityEnabled(this);
    }

    private void refreshStatuses() {
        if (focusStatus == null) return;
        updateCompletedSessionReward();
        boolean focusOn = ProtectionPrefs.isFocusActive(this);
        long until = ProtectionPrefs.focusUntil(this);
        long totalDuration = ProtectionPrefs.prefs(this).getLong(ProtectionPrefs.KEY_FOCUS_DURATION, 45L * 60L * 1000L);
        if (countdownDial != null) countdownDial.setTimer(focusOn ? until : 0L, totalDuration);
        if (focusOn) {
            long remaining = Math.max(0L, ProtectionPrefs.focusUntil(this) - System.currentTimeMillis());
            long seconds = remaining / 1000L;
            focusStatus.setText(String.format(Locale.ROOT, "FOCUS ACTIVE  %02d:%02d:%02d", seconds / 3600, (seconds % 3600) / 60, seconds % 60));
            focusSubtitle.setText("Selected apps are being restricted until this timer reaches zero.");
            startFocusButton.setText("FOCUS SESSION ACTIVE");
            startFocusButton.setEnabled(false);
            if (strictModeCheck != null) strictModeCheck.setEnabled(false);
        } else {
            focusStatus.setText("Protection is ready");
            focusSubtitle.setText("Screen checks stay on this device. Enable only the permissions you want to use.");
            startFocusButton.setText("START FOCUS SESSION");
            startFocusButton.setEnabled(true);
            if (strictModeCheck != null) strictModeCheck.setEnabled(true);
        }
        boolean aiReady = ModelManager.isReady(this);
        aiStatus.setText(aiReady ? "On-device AI model installed" : "AI model is not installed");
        aiStatus.setTextColor(aiReady ? TEAL : WHITE);
        Set<String> selected = ProtectionPrefs.blockedPackages(this);
        appSelectionStatus.setText(selected.size() + " apps selected for Focus Mode");
        boolean accessibility = isAccessibilityEnabled();
        accessibilityStatus.setText("Accessibility: " + (accessibility ? "ENABLED" : "NOT ENABLED"));
        accessibilityStatus.setTextColor(accessibility ? TEAL : AMBER);
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
        boolean admin = dpm.isAdminActive(new ComponentName(this, NexasDeviceAdminReceiver.class));
        adminStatus.setText("Device Admin: " + (admin ? "ENABLED" : "OPTIONAL / OFF"));
        adminStatus.setTextColor(admin ? TEAL : MUTED);
        boolean live = ProtectionPrefs.prefs(this).getBoolean(ProtectionPrefs.KEY_LIVE_SCAN, false);
        if (shieldPill != null) shieldPill.setText((focusOn || live || accessibility) ? "●  ACTIVE" : "●  READY");
        liveButton.setText(live ? "STOP LIVE SCAN" : "START LIVE SCAN");
        if (liveButtonVisualState == null || liveButtonVisualState.booleanValue() != live) {
            liveButtonVisualState = live;
            liveButton.setBackground(rippleBackground(live ? Color.rgb(255, 236, 239) : PANEL_ALT, 13, live ? RED : OUTLINE));
        }
        liveStatus.setText(live ? "Live AI scan is active. A persistent Android notification is visible." :
                "Live screen analysis requires Android screen-capture consent and shows an ongoing notification.");
        boolean reminder = ProtectionPrefs.prefs(this).getBoolean(ProtectionPrefs.KEY_REMINDER_ENABLED, false);
        if (reminder) {
            int h = ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_REMINDER_HOUR, 20);
            int m = ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_REMINDER_MINUTE, 0);
            signalStatus.setText(String.format(Locale.ROOT, "Daily focus signal • %02d:%02d", h, m));
        } else signalStatus.setText("No daily signal scheduled");
        if (streakStatus != null) streakStatus.setText(ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_STREAK_COUNT, 0) + " day streak");
        if (pointsStatus != null) pointsStatus.setText(ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_FOCUS_POINTS, 0) + " pts");
        if (bestStreakStatus != null) bestStreakStatus.setText("Best " + ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_BEST_STREAK, 0));
        if (dailyGoalStatus != null && dailyGoalProgress != null) {
            int completed = getTodayFocusMinutes();
            int goal = ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_DAILY_GOAL_MINUTES, 120);
            dailyGoalStatus.setText(completed + " / " + goal + " minutes today");
            dailyGoalProgress.setProgress(Math.min(100, Math.round((completed * 100f) / Math.max(1, goal))));
        }
        if (blockImageStatus != null) {
            String image = ProtectionPrefs.prefs(this).getString(ProtectionPrefs.KEY_BLOCK_SCREEN_IMAGE, "");
            blockImageStatus.setText(image == null || image.isEmpty() ? "No custom block-screen image selected" : "Custom block-screen image is ready");
        }
    }

    private void pickBlockScreenImage() {
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType("image/*");
        startActivityForResult(pick, REQUEST_BLOCK_IMAGE);
    }

    private void updateCompletedSessionReward() {
        long focusUntil = ProtectionPrefs.prefs(this).getLong(ProtectionPrefs.KEY_FOCUS_UNTIL, 0L);
        long lastRewardedUntil = ProtectionPrefs.prefs(this).getLong(ProtectionPrefs.KEY_LAST_COMPLETED_UNTIL, 0L);
        if (focusUntil > 0L && focusUntil <= System.currentTimeMillis() && focusUntil != lastRewardedUntil) {
            java.util.Calendar cal = java.util.Calendar.getInstance();
            int today = cal.get(java.util.Calendar.YEAR) * 1000 + cal.get(java.util.Calendar.DAY_OF_YEAR);
            int lastDay = ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_LAST_COMPLETED_DAY, 0);
            int streak = ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_STREAK_COUNT, 0);
            int best = ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_BEST_STREAK, 0);
            // Calendar-aware previous-day comparison handles year boundaries.
            java.util.Calendar prev = java.util.Calendar.getInstance(); prev.add(java.util.Calendar.DAY_OF_YEAR, -1);
            int previousDay = prev.get(java.util.Calendar.YEAR) * 1000 + prev.get(java.util.Calendar.DAY_OF_YEAR);
            if (lastDay == today) { /* A second completed session today keeps the same streak. */ }
            else if (lastDay == previousDay) streak++;
            else streak = 1;
            best = Math.max(best, streak);
            int points = ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_FOCUS_POINTS, 0) + 25;
            int todayMinutes = getTodayFocusMinutes();
            int sessionMinutes = (int) Math.max(1L, ProtectionPrefs.prefs(this).getLong(ProtectionPrefs.KEY_FOCUS_DURATION, 45L * 60L * 1000L) / 60_000L);
            ProtectionPrefs.prefs(this).edit()
                    .putInt(ProtectionPrefs.KEY_FOCUS_DAY_KEY, today)
                    .putInt(ProtectionPrefs.KEY_TODAY_FOCUS_MINUTES, todayMinutes + sessionMinutes)
                    .putInt(ProtectionPrefs.KEY_STREAK_COUNT, streak)
                    .putInt(ProtectionPrefs.KEY_BEST_STREAK, best)
                    .putInt(ProtectionPrefs.KEY_FOCUS_POINTS, points)
                    .putInt(ProtectionPrefs.KEY_LAST_COMPLETED_DAY, today)
                    .putLong(ProtectionPrefs.KEY_LAST_COMPLETED_UNTIL, focusUntil)
                    .putLong(ProtectionPrefs.KEY_FOCUS_UNTIL, 0L).apply();
            toast("Focus session complete • +25 points");
        }
    }

    private int getTodayFocusMinutes() {
        java.util.Calendar cal = java.util.Calendar.getInstance();
        int today = cal.get(java.util.Calendar.YEAR) * 1000 + cal.get(java.util.Calendar.DAY_OF_YEAR);
        int savedDay = ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_FOCUS_DAY_KEY, today);
        if (savedDay != today) return 0;
        return ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_TODAY_FOCUS_MINUTES, 0);
    }

    private void startBreathingReset() {
        final TextView prompt = text("Breathe in slowly…", 22, WHITE, true);
        prompt.setGravity(Gravity.CENTER);
        LinearLayout layout = new LinearLayout(this); layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(18), dp(24), dp(18), dp(24)); layout.setBackground(round(PANEL, 18, OUTLINE));
        layout.addView(prompt, fullWidth());
        TextView details = text("Follow four gentle cycles. This is a short reset, not a performance test.", 12, MUTED, false);
        LinearLayout.LayoutParams det = fullWrap(); det.topMargin = dp(12); layout.addView(details, det);
        final AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Breathing reset").setView(layout).setNegativeButton("Close", null).create();
        dialog.setOnShowListener(d -> {
            final int[] phase = {0};
            final Runnable[] cycle = new Runnable[1];
            cycle[0] = () -> {
                if (!dialog.isShowing()) return;
                int n = phase[0]++;
                if (n >= 8) { prompt.setText("Reset complete"); details.setText("Take the next step with intention."); return; }
                prompt.setText((n % 2 == 0) ? "Breathe in • 4" : "Breathe out • 6");
                prompt.animate().alpha(0.65f).setDuration(450).withEndAction(() -> prompt.animate().alpha(1f).setDuration(450).start()).start();
                handler.postDelayed(cycle[0], n % 2 == 0 ? 4000L : 6000L);
            };
            cycle[0].run();
        });
        dialog.show();
    }

    private void startPatternGame() {
        final String[] patterns = {"4 1 7", "2 8 3 6", "9 5 1 4 7"};
        final int[] round = {0};
        final TextView patternView = text(patterns[0], 28, TEAL, true); patternView.setGravity(Gravity.CENTER);
        final EditText answer = editText("", "Type the pattern you remember");
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18), dp(18), dp(18), dp(18));
        box.addView(text("Memorise the sequence, then enter it when hidden.", 12, MUTED, false));
        LinearLayout.LayoutParams pp = fullWidth(); pp.height = dp(58); pp.topMargin = dp(12); box.addView(patternView, pp);
        LinearLayout.LayoutParams ap = fullWidth(); ap.height = dp(58); ap.topMargin = dp(10); box.addView(answer, ap);
        final AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Pattern memory").setView(box)
                .setNegativeButton("Close", null).setPositiveButton("Check", null).create();
        dialog.setOnShowListener(d -> {
            Button check = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            patternView.postDelayed(() -> { if (dialog.isShowing()) patternView.setText("••••  HIDDEN  ••••"); }, 2200L);
            check.setOnClickListener(v -> {
                if (answer.getText().toString().trim().replaceAll("\\s+", " ").equals(patterns[round[0]])) {
                    round[0]++;
                    if (round[0] >= patterns.length) {
                        int points = ProtectionPrefs.prefs(this).getInt(ProtectionPrefs.KEY_FOCUS_POINTS, 0) + 5;
                        ProtectionPrefs.prefs(this).edit().putInt(ProtectionPrefs.KEY_FOCUS_POINTS, points).apply();
                        toast("Pattern game complete • +5 points"); dialog.dismiss(); refreshStatuses();
                    } else {
                        patternView.setText(patterns[round[0]]); answer.setText("");
                        final int next = round[0];
                        patternView.postDelayed(() -> { if (dialog.isShowing() && round[0] == next) patternView.setText("••••  HIDDEN  ••••"); }, 2200L);
                    }
                } else { answer.setError("Not quite. Try again."); }
            });
        });
        dialog.show();
    }

    private final class CountdownDial extends View {
        private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint progress = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint haloPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint tickPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint particlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint innerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF arcBounds = new RectF();
        private long endAt = 0L;
        private long duration = 45L * 60L * 1000L;
        private final int[] ringColors = new int[]{Color.rgb(20, 164, 139), Color.rgb(115, 101, 211), Color.rgb(20, 164, 139)};

        CountdownDial(Context context) {
            super(context);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            track.setStyle(Paint.Style.STROKE); track.setStrokeWidth(dp(10)); track.setStrokeCap(Paint.Cap.ROUND); track.setColor(Color.rgb(235, 240, 247));
            progress.setStyle(Paint.Style.STROKE); progress.setStrokeWidth(dp(11)); progress.setStrokeCap(Paint.Cap.ROUND);
            haloPaint.setStyle(Paint.Style.STROKE); haloPaint.setStrokeWidth(dp(19)); haloPaint.setColor(Color.argb(20, 20, 164, 139));
            tickPaint.setStrokeCap(Paint.Cap.ROUND); tickPaint.setStrokeWidth(dp(1));
            particlePaint.setStyle(Paint.Style.FILL);
            innerPaint.setStyle(Paint.Style.STROKE); innerPaint.setStrokeWidth(dp(1)); innerPaint.setColor(Color.rgb(241, 245, 250));
            textPaint.setColor(WHITE); textPaint.setTextAlign(Paint.Align.CENTER); textPaint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            labelPaint.setColor(MUTED); labelPaint.setTextAlign(Paint.Align.CENTER); labelPaint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        }

        void setTimer(long until, long total) {
            endAt = until; duration = Math.max(60_000L, total); invalidate();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float radius = Math.min(getWidth(), getHeight()) * 0.365f;
            long now = System.currentTimeMillis();
            boolean active = endAt > now;
            // The ring fills clockwise as the session progresses: empty at the start,
            // complete at zero remaining time. The digital clock remains readable in its centre.
            float remainingFraction = active ? Math.max(0f, Math.min(1f, (endAt - now) / (float) duration)) : 0f;
            float fraction = active ? 1f - remainingFraction : 0f;
            float pulse = 0.5f + 0.5f * (float)Math.sin(now / 720.0);

            // Soft ambient halo and layered guide rings create depth without bitmap assets.
            haloPaint.setColor(Color.argb(active ? (int)(18 + 12 * pulse) : 12, 20, 164, 139));
            canvas.drawCircle(cx, cy, radius + dp(7), haloPaint);
            track.setStrokeWidth(dp(10));
            canvas.drawCircle(cx, cy, radius, track);
            canvas.drawCircle(cx, cy, radius - dp(17), innerPaint);

            // Sixty precision marks; every fifth mark receives a stronger accent.
            for (int i = 0; i < 60; i++) {
                double a = Math.toRadians(i * 6d - 90d);
                boolean major = i % 5 == 0;
                float inner = radius + (major ? dp(9) : dp(11));
                float outer = radius + dp(major ? 17 : 14);
                float x1 = cx + (float)Math.cos(a) * inner;
                float y1 = cy + (float)Math.sin(a) * inner;
                float x2 = cx + (float)Math.cos(a) * outer;
                float y2 = cy + (float)Math.sin(a) * outer;
                tickPaint.setColor(major ? Color.rgb(168, 190, 203) : Color.rgb(218, 227, 237));
                tickPaint.setStrokeWidth(dp(major ? 1.7f : 0.8f));
                canvas.drawLine(x1, y1, x2, y2, tickPaint);
            }

            progress.setShader(new SweepGradient(cx, cy, ringColors, null));
            canvas.save(); canvas.rotate(-90f, cx, cy);
            if (active && fraction > 0.001f) {
                Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
                glow.setStyle(Paint.Style.STROKE); glow.setStrokeCap(Paint.Cap.ROUND);
                glow.setStrokeWidth(dp(17)); glow.setColor(Color.argb((int)(28 + 18 * pulse), 20, 164, 139));
                float sweep = 360f * fraction;
                canvas.drawArc(arcBoundsFor(cx, cy, radius), 0f, sweep, false, glow);
                canvas.drawArc(arcBoundsFor(cx, cy, radius), 0f, sweep, false, progress);
            }
            canvas.restore();
            progress.setShader(null);

            // Orbit particles drift smoothly and are redrawn with the once-per-second timer tick.
            if (active) {
                for (int i = 0; i < 18; i++) {
                    double a = Math.toRadians((i * 20d) + (now / 170.0));
                    float orbit = radius + dp(24) + (float)Math.sin(now / 460.0 + i) * dp(2);
                    float px = cx + (float)Math.cos(a) * orbit;
                    float py = cy + (float)Math.sin(a) * orbit;
                    int alpha = 35 + (int)(75 * (0.5 + 0.5 * Math.sin(now / 380.0 + i)));
                    particlePaint.setColor(Color.argb(alpha, 20, 164, 139));
                    canvas.drawCircle(px, py, dp((i % 3 == 0) ? 2.2f : 1.3f), particlePaint);
                }
                double angle = Math.toRadians(-90d + 360d * fraction);
                float dotX = cx + (float)Math.cos(angle) * radius;
                float dotY = cy + (float)Math.sin(angle) * radius;
                particlePaint.setColor(Color.argb(55, 20, 164, 139));
                canvas.drawCircle(dotX, dotY, dp(12 + 2 * pulse), particlePaint);
                particlePaint.setColor(Color.WHITE);
                canvas.drawCircle(dotX, dotY, dp(5.5f), particlePaint);
                particlePaint.setColor(TEAL);
                canvas.drawCircle(dotX, dotY, dp(3.2f), particlePaint);
            }

            String timeText;
            String label;
            if (active) {
                long secs = Math.max(0L, (endAt - now) / 1000L);
                timeText = secs >= 3600L ? String.format(Locale.ROOT, "%02d:%02d:%02d", secs/3600L, (secs%3600L)/60L, secs%60L)
                        : String.format(Locale.ROOT, "%02d:%02d", secs/60L, secs%60L);
                label = "TIME LEFT";
            } else { timeText = "READY"; label = "YOUR NEXT FOCUS SESSION"; }
            textPaint.setTextSize(dp(active ? 29 : 28));
            canvas.drawText(timeText, cx, cy + dp(5), textPaint);
            labelPaint.setTextSize(dp(9));
            canvas.drawText(label, cx, cy + dp(27), labelPaint);
            if (active) {
                labelPaint.setColor(TEAL); labelPaint.setTextSize(dp(9));
                canvas.drawText("SESSION COMPLETE  ·  " + Math.round(fraction * 100) + "%", cx, cy + dp(48), labelPaint);
                labelPaint.setColor(MUTED);
            } else {
                labelPaint.setColor(VIOLET); labelPaint.setTextSize(dp(8));
                canvas.drawText("A LITTLE PROGRESS, EVERY DAY", cx, cy + dp(48), labelPaint);
                labelPaint.setColor(MUTED);
            }
        }

        private RectF arcBoundsFor(float cx, float cy, float radius) {
            arcBounds.set(cx - radius, cy - radius, cx + radius, cy + radius);
            return arcBounds;
        }

    }

    private void addAction(View view, Runnable action) { view.setOnClickListener(v -> action.run()); }

    private EditText editText(String value, String hint) {
        EditText edit = new EditText(this);
        edit.setText(value);
        edit.setHint(hint);
        edit.setTextColor(WHITE);
        edit.setHintTextColor(Color.rgb(145, 157, 174));
        edit.setTextSize(13);
        edit.setPadding(dp(13), dp(10), dp(13), dp(10));
        edit.setGravity(Gravity.TOP | Gravity.START);
        edit.setBackground(round(Color.rgb(248, 250, 253), 13, OUTLINE));
        return edit;
    }

    private Button button(String label, int color) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor((color == TEAL || color == VIOLET || color == AMBER) ? Color.WHITE : WHITE);
        b.setTextSize(11);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        b.setAllCaps(false);
        b.setLetterSpacing(0.035f);
        b.setPadding(dp(10), dp(7), dp(10), dp(7));
        b.setMinHeight(dp(48));
        b.setBackground(rippleBackground(color, 14, (color == TEAL || color == VIOLET || color == AMBER) ? color : OUTLINE));
        b.setElevation(dp(2));
        b.setOnTouchListener((v, event) -> {
            if (event.getAction() == android.view.MotionEvent.ACTION_DOWN) {
                v.animate().scaleX(0.965f).scaleY(0.965f).translationZ(dp(4)).alpha(0.94f)
                        .setDuration(100).setInterpolator(new AccelerateDecelerateInterpolator()).start();
                v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
            } else if (event.getAction() == android.view.MotionEvent.ACTION_UP
                    || event.getAction() == android.view.MotionEvent.ACTION_CANCEL) {
                v.animate().scaleX(1f).scaleY(1f).translationZ(0f).alpha(1f)
                        .setDuration(190).setInterpolator(new android.view.animation.OvershootInterpolator(1.15f)).start();
            }
            return false;
        });
        return b;
    }

    private RippleDrawable rippleBackground(int color, int radius, int stroke) {
        GradientDrawable content;
        if (color == TEAL || color == VIOLET || color == AMBER) {
            int lighter = blend(color, Color.WHITE, 0.16f);
            content = gradient(new int[]{lighter, color}, radius, stroke);
        } else {
            content = round(color, radius, stroke);
        }
        GradientDrawable mask = round(Color.WHITE, radius, Color.WHITE);
        int rippleColor = (color == TEAL || color == VIOLET || color == AMBER)
                ? Color.argb(62, 255, 255, 255) : Color.argb(44, 20, 164, 139);
        return new RippleDrawable(ColorStateList.valueOf(rippleColor), content, mask);
    }

    private int blend(int from, int to, float amount) {
        float inverse = 1f - amount;
        return Color.rgb(
                Math.round(Color.red(from) * inverse + Color.red(to) * amount),
                Math.round(Color.green(from) * inverse + Color.green(to) * amount),
                Math.round(Color.blue(from) * inverse + Color.blue(to) * amount));
    }

    private Button smallButton(String label, int color) {
        Button b = button(label, color);
        b.setTextSize(10);
        return b;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private GradientDrawable round(int color, int radiusDp, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        d.setStroke(dp(1), strokeColor);
        return d;
    }

    private GradientDrawable gradient(int[] colors, int radiusDp, int strokeColor) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        d.setCornerRadius(dp(radiusDp));
        if (strokeColor != null) d.setStroke(dp(1), strokeColor);
        return d;
    }

    private void animateEntrance(View view, long delay) {
        view.setAlpha(0f);
        view.setTranslationY(dp(18));
        view.setScaleX(0.988f);
        view.setScaleY(0.988f);
        view.postDelayed(() -> view.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).setDuration(520)
                .setInterpolator(new android.view.animation.OvershootInterpolator(0.72f)).start(), delay);
    }

    private void pulse(View view) {
        ObjectAnimator sx = ObjectAnimator.ofFloat(view, View.SCALE_X, 1f, 1.09f, 1f);
        ObjectAnimator sy = ObjectAnimator.ofFloat(view, View.SCALE_Y, 1f, 1.09f, 1f);
        sx.setDuration(2400); sy.setDuration(2400);
        sx.setRepeatCount(ValueAnimator.INFINITE); sy.setRepeatCount(ValueAnimator.INFINITE);
        sx.setInterpolator(new AccelerateDecelerateInterpolator()); sy.setInterpolator(new AccelerateDecelerateInterpolator());
        AnimatorSet set = new AnimatorSet(); set.playTogether(sx, sy); set.start();
    }

    private LinearLayout.LayoutParams fullWrap() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
    private LinearLayout.LayoutParams fullWidth() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)); }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private float dp(float value) { return value * getResources().getDisplayMetrics().density; }

    private void hideKeyboard(View view) {
        if (view == null) return;
        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(view.getWindowToken(), 0);
        view.clearFocus();
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_SCREEN_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                Intent service = new Intent(this, ScreenCaptureService.class);
                service.putExtra("resultCode", resultCode);
                service.putExtra("projectionData", data);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
                toast("Live screen protection starting");
            } else toast("Screen capture was not enabled");
        } else if (requestCode == REQUEST_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            scanPickedImage(data.getData());
        } else if (requestCode == REQUEST_BLOCK_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri selected = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(selected, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                ProtectionPrefs.prefs(this).edit().putString(ProtectionPrefs.KEY_BLOCK_SCREEN_IMAGE, selected.toString()).apply();
                toast("Block-screen image saved");
            } catch (Exception ex) { toast("Could not save image permission: " + ex.getMessage()); }
        }
        refreshStatuses();
    }
}
