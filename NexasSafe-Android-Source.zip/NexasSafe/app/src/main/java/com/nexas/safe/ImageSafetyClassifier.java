package com.nexas.safe;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import org.tensorflow.lite.Interpreter;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Local visual content detector. It never uploads or stores the image being checked. */
final class ImageSafetyClassifier implements Closeable {
    static final int INPUT_SIZE = 640;
    static final float BLOCK_THRESHOLD = 0.55f;
    // YOLO output channels 0..3 are box coordinates. Class scores start at channel 4.
    // These are the NudeNet classes: exposed buttocks, female breast, female genitalia,
    // anus, and male genitalia (class IDs 2, 3, 4, 6, 14 respectively).
    private static final int[] SENSITIVE_OUTPUT_CHANNELS = {6, 7, 8, 10, 18};
    private final Interpreter interpreter;
    private final int outputChannels;
    private final int anchors;

    static final class Result {
        final boolean flagged;
        final float confidence;
        Result(boolean flagged, float confidence) {
            this.flagged = flagged;
            this.confidence = confidence;
        }
    }

    ImageSafetyClassifier(File model) throws IOException {
        if (!model.isFile()) throw new IOException("AI model is not installed");
        Interpreter.Options options = new Interpreter.Options().setNumThreads(2);
        interpreter = new Interpreter(model, options);
        int[] shape = interpreter.getOutputTensor(0).shape();
        if (shape.length != 3 || shape[0] != 1 || shape[1] < 19 || shape[2] != 8400) {
            interpreter.close();
            throw new IOException("Unsupported AI model output shape");
        }
        outputChannels = shape[1];
        anchors = shape[2];
    }

    synchronized Result classify(Bitmap source) {
        if (source == null || source.isRecycled()) return new Result(false, 0f);
        Bitmap letterboxed = Bitmap.createBitmap(INPUT_SIZE, INPUT_SIZE, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(letterboxed);
        canvas.drawColor(Color.rgb(114, 114, 114));
        float scale = Math.min((float) INPUT_SIZE / source.getWidth(), (float) INPUT_SIZE / source.getHeight());
        float width = source.getWidth() * scale;
        float height = source.getHeight() * scale;
        float left = (INPUT_SIZE - width) / 2f;
        float top = (INPUT_SIZE - height) / 2f;
        Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        canvas.drawBitmap(source, null, new RectF(left, top, left + width, top + height), paint);

        int[] pixels = new int[INPUT_SIZE * INPUT_SIZE];
        letterboxed.getPixels(pixels, 0, INPUT_SIZE, 0, 0, INPUT_SIZE, INPUT_SIZE);
        letterboxed.recycle();

        ByteBuffer input = ByteBuffer.allocateDirect(INPUT_SIZE * INPUT_SIZE * 3 * 4);
        input.order(ByteOrder.nativeOrder());
        for (int pixel : pixels) {
            input.putFloat(((pixel >> 16) & 0xFF) / 255.0f);
            input.putFloat(((pixel >> 8) & 0xFF) / 255.0f);
            input.putFloat((pixel & 0xFF) / 255.0f);
        }
        input.rewind();

        float[][][] output = new float[1][outputChannels][anchors];
        interpreter.run(input, output);
        float maximum = 0f;
        for (int outputChannel : SENSITIVE_OUTPUT_CHANNELS) {
            if (outputChannel >= outputChannels) continue;
            for (int anchor = 0; anchor < anchors; anchor++) {
                float score = output[0][outputChannel][anchor];
                if (score > maximum) maximum = score;
            }
        }
        return new Result(maximum >= BLOCK_THRESHOLD, maximum);
    }

    @Override public void close() {
        interpreter.close();
    }
}
