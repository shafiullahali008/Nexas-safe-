package com.nexas.safe;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.content.res.ColorStateList;
import android.view.HapticFeedbackConstants;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.Window;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

/** The block screen can be dismissed to Nexas Safe without ending the active focus timer. */
public class BlockActivity extends Activity {
    private static final int BG = Color.rgb(246, 248, 252);
    private static final int WHITE = Color.rgb(27, 41, 61);
    private static final int MUTED = Color.rgb(108, 124, 146);
    private static final int TEAL = Color.rgb(20, 164, 139);
    private final Handler handler = new Handler();
    private TextView countdown;
    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            updateCountdown();
            if (!isFinishing()) handler.postDelayed(this, 1000L);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(BG);
        window.setNavigationBarColor(BG);
        window.getDecorView().setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(20), dp(24), dp(26));
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(226, 249, 242), Color.rgb(235, 241, 255), Color.rgb(250, 243, 255)}));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("NEXAS  /  SAFE", 11, TEAL, true);
        brand.setLetterSpacing(0.16f);
        top.addView(brand, new LinearLayout.LayoutParams(0, -2, 1f));
        Button close = new Button(this);
        close.setText("×");
        close.setTextSize(23);
        close.setTextColor(WHITE);
        close.setAllCaps(false);
        close.setMinWidth(dp(42));
        close.setMinHeight(dp(42));
        close.setBackground(ripple(round(Color.rgb(255, 255, 255), 14, Color.rgb(224, 231, 240)), Color.argb(48, 20, 164, 139)));
        addPressMotion(close);
        close.setOnClickListener(v -> openNexasDashboard());
        top.addView(close, new LinearLayout.LayoutParams(dp(46), dp(46)));
        root.addView(top, matchWrap());

        TextView shield = text("◈", 52, TEAL, true);
        shield.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams shieldLp = matchWrap(); shieldLp.topMargin = dp(24);
        root.addView(shield, shieldLp);
        shield.setScaleX(0.78f); shield.setScaleY(0.78f); shield.setAlpha(0f);
        shield.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(620)
                .setInterpolator(new android.view.animation.OvershootInterpolator(0.85f)).start();
        android.animation.ObjectAnimator shieldPulse = android.animation.ObjectAnimator.ofFloat(shield, android.view.View.ALPHA, 1f, 0.78f, 1f);
        shieldPulse.setDuration(2800L); shieldPulse.setRepeatCount(android.animation.ValueAnimator.INFINITE);
        shieldPulse.setInterpolator(new AccelerateDecelerateInterpolator()); shieldPulse.start();

        TextView brandTitle = text("PROTECTION ACTIVE", 10, TEAL, true);
        brandTitle.setGravity(Gravity.CENTER);
        brandTitle.setLetterSpacing(0.14f);
        LinearLayout.LayoutParams btLp = matchWrap(); btLp.topMargin = dp(12); btLp.bottomMargin = dp(20);
        root.addView(brandTitle, btLp);

        String imageRaw = ProtectionPrefs.prefs(this).getString(ProtectionPrefs.KEY_BLOCK_SCREEN_IMAGE, "");
        if (imageRaw != null && !imageRaw.isEmpty()) {
            ImageView customImage = new ImageView(this);
            customImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
            customImage.setBackground(round(Color.rgb(255, 255, 255), 18, Color.rgb(224, 231, 240)));
            customImage.setClipToOutline(true);
            try {
                customImage.setImageURI(Uri.parse(imageRaw));
                LinearLayout.LayoutParams imageLp = new LinearLayout.LayoutParams(-1, dp(156));
                imageLp.bottomMargin = dp(22);
                root.addView(customImage, imageLp);
            } catch (Exception ignored) { }
        }

        TextView heading = text("Stay pure.", 34, WHITE, true);
        heading.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams headingLp = matchWrap(); headingLp.bottomMargin = dp(12);
        root.addView(heading, headingLp);

        String customMessage = ProtectionPrefs.prefs(this).getString(ProtectionPrefs.KEY_BLOCK_SCREEN_TEXT,
                "This content has been blocked to protect your focus.");
        if (customMessage == null || customMessage.trim().isEmpty()) {
            customMessage = "This content has been blocked to protect your focus.";
        }
        TextView message = text(customMessage, 15, MUTED, false);
        message.setGravity(Gravity.CENTER);
        message.setLineSpacing(dp(4), 1.0f);
        LinearLayout.LayoutParams messageLp = new LinearLayout.LayoutParams(-1, -2);
        messageLp.bottomMargin = dp(22);
        root.addView(message, messageLp);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(17), dp(17), dp(17), dp(17));
        card.setBackground(round(Color.rgb(255, 255, 255), 19, Color.rgb(224, 231, 240)));
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, -2);
        cardLp.bottomMargin = dp(22);
        root.addView(card, cardLp);
        LinearLayout statusRow = new LinearLayout(this);
        statusRow.setGravity(Gravity.CENTER_VERTICAL);
        statusRow.addView(text("FOCUS SESSION", 10, MUTED, true), new LinearLayout.LayoutParams(0, -2, 1f));
        statusRow.addView(text("●  PROTECTED", 10, TEAL, true));
        card.addView(statusRow);
        countdown = text("", 25, WHITE, true);
        LinearLayout.LayoutParams countdownLp = matchWrap(); countdownLp.topMargin = dp(13);
        card.addView(countdown, countdownLp);
        TextView sub = text("Opening Nexas Safe will not stop this countdown.", 11, MUTED, false);
        LinearLayout.LayoutParams subLp = matchWrap(); subLp.topMargin = dp(5); card.addView(sub, subLp);

        Button openApp = new Button(this);
        openApp.setText("OPEN NEXAS SAFE");
        openApp.setTextColor(Color.WHITE);
        openApp.setTextSize(13);
        openApp.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        openApp.setAllCaps(false);
        openApp.setLetterSpacing(0.05f);
        openApp.setBackground(ripple(round(TEAL, 15, TEAL), Color.argb(68, 255, 255, 255)));
        addPressMotion(openApp);
        openApp.setOnClickListener(v -> openNexasDashboard());
        root.addView(openApp, new LinearLayout.LayoutParams(-1, dp(54)));

        TextView footer = text("YOU CAN DISMISS THIS SCREEN • FOCUS MODE STAYS ACTIVE", 9, Color.rgb(145, 157, 174), true);
        footer.setGravity(Gravity.CENTER);
        footer.setLetterSpacing(0.04f);
        LinearLayout.LayoutParams footerLp = matchWrap(); footerLp.topMargin = dp(18);
        root.addView(footer, footerLp);

        setContentView(root);
        root.setAlpha(0f); root.setTranslationY(dp(12));
        root.animate().alpha(1f).translationY(0f).setDuration(440)
                .setInterpolator(new AccelerateDecelerateInterpolator()).start();
        headingEntrance(root);
        updateCountdown();
    }

    @Override protected void onResume() {
        super.onResume();
        handler.removeCallbacks(ticker);
        handler.post(ticker);
    }

    @Override protected void onPause() {
        handler.removeCallbacks(ticker);
        super.onPause();
    }

    private void updateCountdown() {
        if (countdown == null) return;
        if (!ProtectionPrefs.isFocusActive(this)) {
            countdown.setText("Protection ready");
            return;
        }
        long remaining = Math.max(0L, ProtectionPrefs.focusUntil(this) - System.currentTimeMillis());
        long seconds = remaining / 1000L;
        countdown.setText(String.format(Locale.ROOT, "%02d:%02d:%02d remaining",
                seconds / 3600L, (seconds % 3600L) / 60L, seconds % 60L));
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private RippleDrawable ripple(GradientDrawable content, int rippleColor) {
        GradientDrawable mask = round(Color.WHITE, 16, Color.WHITE);
        return new RippleDrawable(ColorStateList.valueOf(rippleColor), content, mask);
    }

    private void addPressMotion(Button button) {
        button.setElevation(dp(2));
        button.setOnTouchListener((view, event) -> {
            if (event.getAction() == android.view.MotionEvent.ACTION_DOWN) {
                view.animate().scaleX(0.965f).scaleY(0.965f).translationZ(dp(4)).setDuration(100).start();
                view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
            } else if (event.getAction() == android.view.MotionEvent.ACTION_UP
                    || event.getAction() == android.view.MotionEvent.ACTION_CANCEL) {
                view.animate().scaleX(1f).scaleY(1f).translationZ(0f).setDuration(190)
                        .setInterpolator(new android.view.animation.OvershootInterpolator(1.12f)).start();
            }
            return false;
        });
    }

    private void headingEntrance(LinearLayout root) {
        for (int i = 0; i < root.getChildCount(); i++) {
            android.view.View child = root.getChildAt(i);
            if (child instanceof TextView) {
                child.setAlpha(0f);
                child.animate().alpha(1f).setStartDelay(90L + i * 28L).setDuration(360L).start();
            }
        }
    }

    private GradientDrawable round(int color, int radius, int stroke) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(-1, -2); }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private void openNexasDashboard() {
        Intent app = new Intent(this, MainActivity.class);
        app.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(app);
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    private void goHome() {
        Intent home = new Intent(Intent.ACTION_MAIN);
        home.addCategory(Intent.CATEGORY_HOME);
        home.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(home);
        finish();
    }

    @Override public void onBackPressed() { openNexasDashboard(); }
}
